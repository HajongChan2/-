package com.example.igonan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IgonanApplication {

	public static void main(String[] args) {

		SpringApplication.run(IgonanApplication.class, args);
	}

}

$(document).ready(function(){
    $.ajax({
        type : "POST",
        url : "/dog/list",
        dataType : "json",
        success : function(data){
           dogList(data);

            console.log(data);
        }
    });

    function dogList(list){
        let name = '';
        let addr = "/dog/detail";
        let str = '';
        list.map(function(petdog){
            str +=
                `<div class="pet_dog-wrap">
                    <a href="${addr}">
                    <div class="pet_dog-image"><img src="${petdog.pdGallery}" alt=""></div>
                    <div class="pet_dog-text">
                        <p>${petdog.pdName}</p>
                    </div>
                </div>
`

        });
        $("#container2").append(str);
    }

    $(document).on("click", ".pet_dog-text p", function(e){
        let na = $(e.target);
        name = na.text();
        console.log(name);
        localStorage.setItem('name',name);
    });



});
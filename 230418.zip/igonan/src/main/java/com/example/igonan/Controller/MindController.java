package com.example.igonan.Controller;


import com.example.igonan.Service.PaymentService;
import com.example.igonan.minddto.Paymentmapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class MindController {

    @Autowired
    Paymentmapper mindin;

    private PaymentService paymentService;

    public PaymentService getPaymentService() {
        return paymentService;
    }

    @RequestMapping("/main")
    public String main( ) {

        return "main";
    }
    @RequestMapping("/info")
    public String information( ) {

        return "information";
    }
    @RequestMapping("/abandog/detail")
    public String abandog_detail( ) {

        return "abandog_detail";
    }
    @RequestMapping("/abandog/form")
    public String abandog_form( ) {

        return "abandog_form";
    }
    @RequestMapping("/dog/adoption")
    public String dog_adoption( ) {

        return "dog_adoption";
    }

    @RequestMapping("/dog/detail")
    public String dog_detail_inq( ) {

        return "dog_detail_inq";
    }

    @RequestMapping("/dog/select")
    public String dog_inquiry( ) {

        return "dog_inquiry";
    }
    @RequestMapping("/dog/detail/form")
    public String dog_infomation_detail( ) {

        return "dog_infomation_detail";
    }


    @RequestMapping("/petcesary")
    public String petcesary(){

        return "petcesory";
    }
    @RequestMapping("/product/detail")
    public String petcede(){

        return "product_detail";
    }

    @RequestMapping("/payment")
    public String payment(){

        return "payment";
    }
    @RequestMapping("/purchase")
    public String purchase(){

        return "purchase_select";
    }

    @PostMapping("/payment/insert") //해당 url로 데이터가 post 되었을 경우 실행
    public String paymentinsert(HttpServletRequest rq){ //보내진 데이터이용을 위해 HttpServletRequest를 rq로 선언하여 이용
        int pr_count = 0; // 사용자가 구매하려는 상품의 개수를 담는 변수
        if(rq.getParameter("count")==null){ // 사용자가 구매하려는 상품의 개수가 post되지 않으면 0을 담음
            pr_count = 0;
        }else {
            pr_count = Integer.parseInt(rq.getParameter("count"));
            //사용자가 구매하려는 상품의 개수를 int형으로 변환하여 담음
        }

        mindin.mindpaymentinsert(   //구매자 주문정보를 insert하는 mindpaymentinsert 호출과 파라미터 값 입력
                rq.getParameter("user_name"),
                rq.getParameter("phone"),rq.getParameter("addr"),
                rq.getParameter("saddr"),rq.getParameter("memo"),
                //Integer.parseInt(rq.getParameter("p_count")),
                pr_count,rq.getParameter("payment_method")
        );

        return "redirect:/users"; //insert 완료 시 /users 로 리다이렉트하여 주문자 리스트를 보여줌
    }


    @RequestMapping("/ttttt")
    public String test(){

        return "test";
    }

    @RequestMapping("/doglist")
    public String dogdogtest(){

        return "testdog";
    }
    @RequestMapping("/onedog")
    public String dogparamtest(){

        return "testparamdog";
    }

}

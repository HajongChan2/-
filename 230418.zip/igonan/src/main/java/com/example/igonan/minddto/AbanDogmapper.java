package com.example.igonan.minddto;

import com.example.igonan.dto.AbandogDTO;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Mapper
@Transactional
public interface AbanDogmapper {

    @Select("select * from a_dog;")
    List<AbandogDTO> abanDogList();
    // 모든 유기견의 정보를 List에 담음

    @Select("select * from a_dog ad where ad.a_name = #{dogname} ;")
    List<AbandogDTO> findOneDog(String dogname);
    // 특정 유기견의 정보를 List에 담음

}

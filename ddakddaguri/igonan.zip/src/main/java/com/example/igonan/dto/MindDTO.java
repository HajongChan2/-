package com.example.igonan.dto;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MindDTO {

    private String uName;
    private String uPhone;
    private String uAddr;
    private String uSaddr;
    private String uMemo;

    public String getuName() {
        return uName;
    }

    public String getuPhone() {
        return uPhone;
    }

    public String getuAddr() {
        return uAddr;
    }

    public String getuSaddr() {
        return uSaddr;
    }

    public String getuMemo() {
        return uMemo;
    }
}

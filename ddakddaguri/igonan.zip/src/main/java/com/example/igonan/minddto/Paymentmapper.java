package com.example.igonan.minddto;

import com.example.igonan.dto.MindDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
@Mapper
@Transactional
public interface Paymentmapper {

@Select("select * from ubuy;")
 List<MindDTO> userBuyList();

@Select("select * from ubuy u where u.u_name = 'asd' ;")
MindDTO findOne();


 Integer mindpaymentinsert(String name, String phone,String addr, String saddr,String memo);


}

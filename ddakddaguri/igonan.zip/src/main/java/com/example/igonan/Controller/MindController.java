package com.example.igonan.Controller;


import com.example.igonan.Service.PaymentService;
import com.example.igonan.dto.MindDTO;
import com.example.igonan.minddto.Paymentmapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class MindController {

    @Autowired
    Paymentmapper mindm;

    private PaymentService paymentService;

    public PaymentService getPaymentService() {
        return paymentService;
    }

    @RequestMapping("/main")
    public String main( ) {

        return "main";
    }


    @RequestMapping("/petcesary")
    public String petcesary(){

        return "petcesory";
    }
    @RequestMapping("/detail")
    public String petcede(){

        return "product_detail";
    }

    @RequestMapping("/payment")
    public String payment(){

        return "payment";
    }
    @RequestMapping("/purchase")
    public String purchase(){

        return "purchase_select";
    }

    @PostMapping("/payment/insert")
    public String paymentinsert(HttpServletRequest rq){
        mindm.mindpaymentinsert(
                rq.getParameter("user_name"),
                rq.getParameter("phone"),rq.getParameter("addr"),
                rq.getParameter("saddr"),rq.getParameter("memo")
        );
          System.out.println(rq.getParameter("user_name"));
        System.out.println(rq.getParameter("addr"));
        System.out.println(rq.getParameter("saddr"));
        System.out.println(rq.getParameter("phone"));
        System.out.println(rq.getParameter("memo"));


        return "redirect:/users";
    }





}

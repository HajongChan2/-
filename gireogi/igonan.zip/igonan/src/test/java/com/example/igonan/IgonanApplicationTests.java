package com.example.igonan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IgonanApplicationTests {

	@Test
	void contextLoads() {
	}

}

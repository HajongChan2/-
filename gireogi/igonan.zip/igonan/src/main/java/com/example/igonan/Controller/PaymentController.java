package com.example.igonan.Controller;

import com.example.igonan.Service.PaymentService;
import com.example.igonan.dto.MindDTO;
import com.example.igonan.minddto.Paymentmapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PaymentController {

    @Autowired
    Paymentmapper mindm;

    private PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/users")
    public List<MindDTO> AllUser(){
        return  paymentService.getUsersBuyList();

    }
    @GetMapping("/user")
    public MindDTO oneUser(){
        return  paymentService.getOneBuyList();

    }


}

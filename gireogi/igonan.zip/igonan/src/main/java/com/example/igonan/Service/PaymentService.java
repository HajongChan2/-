package com.example.igonan.Service;


import com.example.igonan.dto.MindDTO;
import com.example.igonan.minddto.Paymentmapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {


    @Autowired
    private Paymentmapper pmm;

    public List<MindDTO> getUsersBuyList(){
        List<MindDTO> userBuyList= pmm.userBuyList();
        return userBuyList;

    }
    public MindDTO getOneBuyList(){
        MindDTO oneBuy = pmm.findOne();
   //     System.out.println(oneBuy.getuPhone());

        return oneBuy;
    }








}

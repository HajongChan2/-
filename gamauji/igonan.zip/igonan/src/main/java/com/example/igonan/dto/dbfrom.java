/*package com.example.igonan.dto;

import com.example.igonan.entity.dbdb;

import javax.persistence.Entity;

@Entity
public class dbfrom {

    private long id;
    private String name;
    private String nickname;

    public dbfrom(String name, String nickname) {
        this.name = name;
        this.nickname = nickname;
    }



    @Override
    public String toString() {
        return "dbfrom{" +
                "name='" + name + '\'' +
                ", nickname='" + nickname + '\'' +
                '}';
    }

    public dbdb toEntity() {
        return new dbdb(null, name, nickname);
    }


}
*/
/*package com.example.igonan.entity;

import com.example.igonan.entity.dbdb;
import org.springframework.data.repository.CrudRepository;

public interface dbdbReposi extends CrudRepository<dbdb, Long> {
}
*/
package com.example.igonan.dbtest;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface sampleinsert {

        // 샘플 조회
        String selectTest();
    }

/*package com.example.igonan.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class dbdb {

    @Id
    @GeneratedValue
    private Long id;

    @Column
    private String name;

    @Column
    private String nickname;


    public dbdb(Long id, String name, String nickname) {
        this.id = id;
        this.name = name;
        this.nickname = nickname;
    }


    @Override
    public String toString() {
        return "dbdb{" +
                "id=" + id +
                "name : '" + name + '\'' +
                ", nickname : '" + nickname + '\'' +
                '}';
    }

}
*/
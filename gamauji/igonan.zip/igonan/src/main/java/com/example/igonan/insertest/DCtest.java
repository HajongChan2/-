package com.example.igonan.insertest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@Controller
public class DCtest {
    @Autowired
    DCinter dao;

    @PostMapping("/dummy/insert")
    public String join(HttpServletRequest request, Model model){
        dao.testinsertMango(request.getParameter("id"),
                request.getParameter("name")
        );
        return "dummyform";


    }


    @RequestMapping("/dummy")
    public String dummmy() {
        return "dummyform";
    }
}

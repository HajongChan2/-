package com.example.igonan.dto;

public class formalin {


    private String name;
    private  String nickname;


    public formalin(String name, String nickname) {
        this.name = name;
        this.nickname = nickname;
    }

    @Override
    public String toString() {
        return "date{" +
                "name : '" + name + '\'' +
                ", nickname : '" + nickname + '\'' +
                '}';
    }








    }


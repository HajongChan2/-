/*
package com.example.igonan.freeboard;


import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class fbcont {

    @Autowired
    SqlSession ss;

    List<freeboarddto> list = new ArrayList<>();
    @RequestMapping(value="/indexx", method = RequestMethod.GET)
    public String index(Model md) {
        list = ss.selectList("freeboard.selectlist");
        md.addAttribute("list",list);
        return "index";
    }
}
*/
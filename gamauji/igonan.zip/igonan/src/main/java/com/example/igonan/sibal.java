package com.example.igonan;

import com.example.igonan.dto.formalin;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class sibal {

    public class mangoCon {

        @RequestMapping("/mango")
        public String newArticleForm() {
            return "mango";
        }
    }



}

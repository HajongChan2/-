package com.example.igonan.insertest;


import org.apache.ibatis.annotations.Mapper;

import com.example.igonan.insertest.DCDTO;

import java.util.List;

@Mapper
public interface DCinter {

    List<DCDTO> testselectMango(String id);
    Integer testinsertMango(String id, String name);
}

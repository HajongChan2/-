package com.example.igonan.insertest;

import lombok.Data;

@Data
public class DCDTO {
    private String id;
    private  String name;
}

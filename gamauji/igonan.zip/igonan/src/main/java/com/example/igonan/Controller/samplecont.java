package com.example.igonan.Controller;

import com.example.igonan.dbtest.sampleservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class samplecont {

    @Autowired
    private sampleservice sampleService;

    @RequestMapping(value="/index", method = {RequestMethod.POST, RequestMethod.GET})
    public String index() {
        System.out.println("select 호출");
        String test = sampleService.selectTest();
        System.out.println("조회 테스트 : "+test);
        return "index";
    }

}

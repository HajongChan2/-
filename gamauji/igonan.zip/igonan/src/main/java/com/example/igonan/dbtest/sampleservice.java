package com.example.igonan.dbtest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.igonan.dbtest.sampleinsert;
@Service
public class sampleservice {


    @Autowired
    private sampleinsert smpinsert;

    public String selectTest(){
        return smpinsert.selectTest();
    }
}
